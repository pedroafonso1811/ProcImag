﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Data.Common;
using System.Data.SqlTypes;
using System.Security.Cryptography;
using System.IO;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms.DataVisualization.Charting;

namespace ProcessamentoConversorImagem
{
    public partial class Form1 : Form
    {
        //Funções
        int Truncate8bits(int val)
        {
            if (val > 255) return 255;
            else if (val < 0) return 0;
            return val;
        }

        int Bin(int val)
        {
            return val >= 128 ? 255 : 0;
        }

        int Cinza(int r, int g, int b)
        {
            return (r + g + b) / 3;
        }

        bool BImagesEmpty()
        {
            return picX.Image == null || picY.Image == null;

        }

        bool bImagesEqual(Bitmap imgX, Bitmap imgY)
        {
            if ((imgX.Width != imgX.Width) && (imgY.Width != imgY.Width))
            {
                MessageBox.Show("As imagem precisam ter o mesmo tamanho de pixel" +
                    "\nWidth: " + "Imagem X: " + imgX.Width + "Imagem Y: " + imgY.Width +
                    "\nHeight: " + "Imagem X: " + imgX.Height + "Imagem Y: " + imgY.Height, "Erro",
                    MessageBoxButtons.OK);
                return false;
            }
            return true;
        }

        bool BCheckCinza(Bitmap img)
        {
            for (int i = 0; i < img.Width; i++)
            {
                for (int y = 0; y < img.Height; y++)
                {
                    Color p = img.GetPixel(i, y);
                    if (p.R != p.G || p.G != p.B) return false;
                }
            }
            return true;
        }

        Bitmap MirrorImage(Bitmap img)
        {
            if (img == null) return null;
            int MirrorWidth = img.Width * 2;
            int MirrorHeight = img.Height;

            Bitmap MirrorImage = new Bitmap(MirrorWidth, MirrorHeight);
            for (int i = 0; i < img.Width; i++)
            {
                for (int y = 0; y < img.Height; y++)
                {
                    Color imgP = img.GetPixel(i, y);
                    Color p = Color.FromArgb(imgP.A,
                        imgP.R,
                        imgP.G,
                        imgP.B);

                    MirrorImage.SetPixel(i, y, p);
                    MirrorImage.SetPixel(MirrorWidth - 1 - i, y, p);
                }
            }
            return MirrorImage;
        }

        void UpdateResultImage(Bitmap img)
        {
            picResult.Image = img;
        }

        byte[] GenMask(byte[,] vImgA_Gray, int i, int j)
        {

            byte[] mask = new byte[9];
            
            //Reseta a máscara
            for (int w = 0; w < mask.Length; w++) mask[w] = 0;

            mask[0] = (byte)(vImgA_Gray[i - 1, j - 1]);
            mask[1] = (byte)(vImgA_Gray[i - 1, j]);
            mask[2] = (byte)(vImgA_Gray[i - 1, j + 1]);

            mask[3] = (byte)(vImgA_Gray[i, j - 1]);
            mask[4] = (byte)(vImgA_Gray[i, j]);
            mask[5] = (byte)(vImgA_Gray[i, j + 1]);

            mask[6] = (byte)(vImgA_Gray[i + 1, j - 1]);
            mask[7] = (byte)(vImgA_Gray[i + 1, j]);
            mask[8] = (byte)(vImgA_Gray[i + 1, j + 1]);

            return mask;
        }

        Bitmap LoadImage()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            var filePath = string.Empty;
            ofd.InitialDirectory = "Projetos 2023 - Segunda feira";
            ofd.Filter = "TIFF image (*.tif)|*.tif|JPG image (*.jpg)|*.jpg|BMP image (*.bmp)|*.bmp|PNG image (*.png)|*.png|All files (*.*)|*.*";
            ofd.FilterIndex = 2;
            ofd.RestoreDirectory = true;

            if (ofd.ShowDialog() == DialogResult.OK)
            {

                filePath = ofd.FileName;

                try
                {
                    return new Bitmap(filePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro ao abrir imagem...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return null;
        }

        void SaveImage(Bitmap img)
        {
            if (img == null) return;

            SaveFileDialog sfd = new SaveFileDialog();
            var filePath = string.Empty;
            sfd.InitialDirectory = "C:\\usuarios";
            sfd.Filter = "TIFF image (*.tif)|*.tif|JPG image (*.jpg)|*.jpg|BMP image (*.bmp)|*.bmp|PNG image (*.png)|*.png|All files (*.*)|*.*";
            sfd.FilterIndex = 2;
            sfd.RestoreDirectory = true;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                img.Save(sfd.FileName);
            }


        }

        //Algumas váriaveis globais, se não, não funciona
        Bitmap imgA, imgB;
        public byte[,] vImgA_Grey, vImgA_R, vImgA_G, vImgA_B, vImgA_A,
            vImgB_Grey, vImgB_R, vImgB_G, vImgB_B, vImgB_A;



        public Form1()
        {
            InitializeComponent();
            picX.SizeMode = PictureBoxSizeMode.StretchImage;
            picY.SizeMode = PictureBoxSizeMode.StretchImage;
            picResult.SizeMode = PictureBoxSizeMode.StretchImage;
            picResult.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void btUpX_Click(object sender, EventArgs e)
        {
            imgA = LoadImage();

            if (imgA == null) //Executa se a imagem carregou sem erros
            {
                return;
            }

            // Adiciona imagem na PictureBox
            picX.Image = imgA;
            vImgA_Grey = new byte[imgA.Width, imgA.Height];
            vImgA_R = new byte[imgA.Width, imgA.Height];
            vImgA_G = new byte[imgA.Width, imgA.Height];
            vImgA_B = new byte[imgA.Width, imgA.Height];
            vImgA_A = new byte[imgA.Width, imgA.Height];

            // Passa pelos pixels da imagem
            for (int i = 0; i < imgA.Width; i++)
            {
                for (int y = 0; y < imgA.Height; y++)
                {
                    Color pixel = imgA.GetPixel(i, y);
                    
                    // Para imagens em escala de cinza, extrair o valor do pixel com...
                    byte pixelIntensity = Convert.ToByte((pixel.R + pixel.G + pixel.B) / 3);

                    vImgA_Grey[i, y] = pixelIntensity;

                    byte R = pixel.R;
                    byte G = pixel.G;
                    byte B = pixel.B;
                    byte A = pixel.A;

                    vImgA_R[i, y] = R;
                    vImgA_G[i, y] = G;
                    vImgA_B[i, y] = B;
                    vImgA_A[i, y] = A;
                }
            }
        }



        private void btUpY_Click(object sender, EventArgs e)
        {
            imgB = LoadImage();

            // Se a imagem carregou perfeitamente...
            if (imgB == null) return;

            picY.Image = imgB;
            vImgB_Grey = new byte[imgB.Width, imgB.Height];
            vImgB_R = new byte[imgB.Width, imgB.Height];
            vImgB_G = new byte[imgB.Width, imgB.Height];
            vImgB_B = new byte[imgB.Width, imgB.Height];
            vImgB_A = new byte[imgB.Width, imgB.Height];

            // Percorre todos os pixels da imagem...
            for (int i = 0; i < imgB.Width; i++)
            {
                for (int y = 0; y < imgB.Height; y++)
                {
                    Color pixel = imgB.GetPixel(i, y);
                    
                    // Para imagens em escala de cinza, extrair o valor do pixel com...
                    byte pixelIntensity = Convert.ToByte((pixel.R + pixel.G + pixel.B) / 3);

                    vImgB_Grey[i, y] = pixelIntensity;

                    byte R = pixel.R;
                    byte G = pixel.G;
                    byte B = pixel.B;
                    byte A = pixel.A;

                    vImgB_R[i, y] = R;
                    vImgB_G[i, y] = G;
                    vImgB_B[i, y] = B;
                    vImgB_A[i, y] = A;
                }
            }
        }




        ////Funções aritmeticas////

        private void btSomar_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y] + vImgB_A[i, y]),
                        (byte)Truncate8bits(vImgA_R[i, y] + vImgB_R[i, y]),
                        (byte)Truncate8bits(vImgA_G[i, y] + vImgB_G[i, y]),
                        (byte)Truncate8bits(vImgA_B[i, y] + vImgB_B[i, y]));


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }
            UpdateResultImage(imgRes);
        }


        private void btSub_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {
                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y]),
                        (byte)Truncate8bits(vImgA_R[i, y] - vImgB_R[i, y]),
                        (byte)Truncate8bits(vImgA_G[i, y] - vImgB_G[i, y]),
                        (byte)Truncate8bits(vImgA_B[i, y] - vImgB_B[i, y]));

                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);

        }



        private void btMulti_Click(object sender, EventArgs e)
        {
            if (picX.Image == null) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            int iMultiplier = 0;

            try
            {
                iMultiplier = Convert.ToInt32(txtMulti.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Multiplicador deve ser numérico mais informações:" + ex.Message, "Erro!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y] * iMultiplier),
                        (byte)Truncate8bits(vImgA_R[i, y] * iMultiplier),
                        (byte)Truncate8bits(vImgA_G[i, y] * iMultiplier),
                        (byte)Truncate8bits(vImgA_B[i, y] * iMultiplier));


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);
        }


        private void btDivi_Click(object sender, EventArgs e)
        {
            if (picX.Image == null) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);
            int Divisor = 0;

            try
            {
                Divisor = Convert.ToInt32(txtDivi.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Divisor deve ser numérico: " + ex.Message, "Erro!",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {
                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y] / Divisor),
                        (byte)Truncate8bits(vImgA_R[i, y] / Divisor),
                        (byte)Truncate8bits(vImgA_G[i, y] / Divisor),
                        (byte)Truncate8bits(vImgA_B[i, y] / Divisor));

                    imgRes.SetPixel(i, y, pixelRes);
                }
            }
            UpdateResultImage(imgRes);
        }



        private void btMed_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            if ((imgB.Width != imgA.Width) && (imgB.Height != imgA.Height))
            {
                MessageBox.Show("As imagens devem ter o mesmo tamanho de pixel." +
                    "\nWidth: " + "Imagem A: " + imgA.Width + " Imagem B: " + imgB.Width +
                    "\nHeight: " + "Imagem B: " + imgA.Height + " Imagem B: " + imgB.Height, "Erro!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits((vImgA_A[i, y] + vImgB_A[i, y]) / 2),
                        (byte)Truncate8bits((vImgA_R[i, y] + vImgB_R[i, y]) / 2),
                        (byte)Truncate8bits((vImgA_G[i, y] + vImgB_G[i, y]) / 2),
                        (byte)Truncate8bits((vImgA_B[i, y] + vImgB_B[i, y]) / 2));


                    imgRes.SetPixel(i, y, pixelRes);
                }
            }
            UpdateResultImage(imgRes);
        }


        private void btBlend_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;


            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);
            double Fator = 0;

            try
            {
                if (txtBlend.Text.Contains("."))
                {
                    MessageBox.Show("O valor decimal deve conter uma virgula ao inves de um ponto. O valor será corrigido para virgula para garantir que nenhum crash aconteca."
                        , "Aviso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBlend.Text = txtBlend.Text.Replace(".", ",");
                }

                Fator = Convert.ToSingle(txtBlend.Text);

                if (Fator > 1)
                {
                    MessageBox.Show("O Blending deve ser entre 0 e 1. O valor vai ser definito para 1", "Aviso!",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Fator = 1;
                    txtBlend.Text = Convert.ToString(Fator);
                }
                else if (Fator < 0)
                {
                    MessageBox.Show("O Blending deve ser entre 0 e 1. O valor vai ser definito para 0", "Aviso!",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Fator = 0;
                    txtBlend.Text = Convert.ToString(Fator);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Valor de blending deve ser numérico! Mais informações: " + ex.Message, "ERRO!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {
                    int A = 0, R = 0, G = 0, B = 0;
                    A = (int)(Fator * vImgA_A[i, y] + (1 - Fator) * vImgB_A[i, y]);
                    R = (int)(Fator * vImgA_R[i, y] + (1 - Fator) * vImgB_R[i, y]);
                    G = (int)(Fator * vImgA_G[i, y] + (1 - Fator) * vImgB_G[i, y]);
                    B = (int)(Fator * vImgA_B[i, y] + (1 - Fator) * vImgB_B[i, y]);

                    Color pixelRes = Color.FromArgb(A, R, G, B);


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }
            UpdateResultImage(imgRes);
        }



        private void btSave_Click(object sender, EventArgs e)
        {
            Bitmap imgRes = (Bitmap)picResult.Image;
            SaveImage(imgRes);
        }

        private void btAlea_Click(object sender, EventArgs e)
        {
            Bitmap imgRNG = new Bitmap(256, 256);
            Random rnd = new Random();

            for (int i = 0; i < imgRNG.Width; i++)
            {
                for (int y = 0; y < imgRNG.Height; y++)
                {
                    int R = rnd.Next(200);
                    int G = rnd.Next(200);
                    int B = rnd.Next(200);

                    Color p = Color.FromArgb(100, R, G, B);
                    imgRNG.SetPixel(i, y, p);
                }
            }
            picResult.Image = imgRNG;
        }


        private void btMIN_Click(object sender, EventArgs e)
        {
            if (imgA == null) return;
            if (imgA.Width < 3 || imgA.Height < 3) return;
            Bitmap imgRes = new Bitmap(imgA);

            int width = imgA.Width;
            int height = imgA.Height;

            for (int i = 1; i < width - 1; i++)
            {
                for (int j = 1; j < height - 1; j++)
                {
                    byte min = GenMask(vImgA_Grey, i, j).Min();
                    Color p = Color.FromArgb(255, min, min, min);
                    imgRes.SetPixel(i, j, p);
                }
            }
            UpdateResultImage(imgRes);
        }
        private void btMedia_Click(object sender, EventArgs e)
        {
            if (imgA == null) return;
            if (imgA.Width < 3 || imgA.Height < 3) return;

            Bitmap imgRes = new Bitmap(imgA);

            int width = imgRes.Width - 1;
            int height = imgRes.Height - 1;

            for (int i = 1; i < width; i++)
            {
                for (int j = 1; j < height; j++)
                {
                    byte[] mask = GenMask(vImgA_Grey, i, j);

                    byte avg = 0;
                    int acc = 0;

                    for (int w = 0; w < mask.Length; w++) acc += mask[w];
                    avg = (byte)(acc / 9);

                    Color p = Color.FromArgb(255,
                      avg,
                      avg,
                      avg);

                    imgRes.SetPixel(i, j, p);
                }
            }
            UpdateResultImage(imgRes);
        }

        private void btMax_Click(object sender, EventArgs e)
        {
            if (imgA == null) return;
            if (imgA.Width < 3 || imgA.Height < 3) return;

            Bitmap imgRes = new Bitmap(imgA);

            int width = imgRes.Width - 1;
            int height = imgRes.Height - 1;

            for (int i = 1; i < width; i++)
            {
                for (int j = 1; j < height; j++)
                {
                    byte max = GenMask(vImgA_Grey, i, j).Max();

                    Color p = Color.FromArgb(255,
                        max,
                        max,
                        max);

                    imgRes.SetPixel(i, j, p);
                }
            }
            UpdateResultImage(imgRes);
        }

        /////////////Parte lógica///////////////////
        private void btAND_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            if ((imgB.Width != imgA.Width) && (imgB.Height != imgA.Height))
            {
                MessageBox.Show("As imagens precisam ter o mesmo tamanho de pixel." +
                    "\nWidth: " + "Imagem A: " + imgA.Width + " Imagem B: " + imgB.Width +
                    "\nHeight: " + "Imagem B: " + imgA.Height + " Imagem B: " + imgB.Height, "Erro!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y] & vImgB_A[i, y]),
                        (byte)Truncate8bits(vImgA_R[i, y] & vImgB_R[i, y]),
                        (byte)Truncate8bits(vImgA_G[i, y] & vImgB_G[i, y]),
                        (byte)Truncate8bits(vImgA_B[i, y] & vImgB_B[i, y]));


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }
            UpdateResultImage(imgRes);
        }
        private void btOR_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);


            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y] | vImgB_A[i, y]),
                        (byte)Truncate8bits(vImgA_R[i, y] | vImgB_R[i, y]),
                        (byte)Truncate8bits(vImgA_G[i, y] | vImgB_G[i, y]),
                        (byte)Truncate8bits(vImgA_B[i, y] | vImgB_B[i, y]));


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);
        }

        private void btXOR_Click(object sender, EventArgs e)
        {
            if (BImagesEmpty()) return;
            if (!bImagesEqual(imgA, imgB)) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);


            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y]),
                        (byte)Truncate8bits(vImgA_R[i, y] ^ vImgB_R[i, y]),
                        (byte)Truncate8bits(vImgA_G[i, y] ^ vImgB_G[i, y]),
                        (byte)Truncate8bits(vImgA_B[i, y] ^ vImgB_B[i, y]));


                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);
        }
        private void btNOT_Click(object sender, EventArgs e)
        {
            if (picX.Image == null) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y]),
                        (byte)Truncate8bits(255 - vImgA_R[i, y]),
                        (byte)Truncate8bits(255 - vImgA_G[i, y]),
                        (byte)Truncate8bits(255 - vImgA_B[i, y]));

                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);
        }


        ////////////Botões negativo e Equalização//////////////
        private void btNeg_Click(object sender, EventArgs e)
        {
            if (picResult.Image == null) return;

            Bitmap imgRes = new Bitmap(imgA.Width, imgA.Height);

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int y = 0; y < imgRes.Height; y++)
                {

                    Color pixelRes = Color.FromArgb(
                        (byte)Truncate8bits(vImgA_A[i, y]),
                        (byte)Truncate8bits(255 - vImgA_R[i, y]),
                        (byte)Truncate8bits(255 - vImgA_G[i, y]),
                        (byte)Truncate8bits(255 - vImgA_B[i, y]));

                    imgRes.SetPixel(i, y, pixelRes);

                }
            }

            UpdateResultImage(imgRes);
        }
        private void btBin_Click(object sender, EventArgs e)
        {
            int imgWidth = 0;
            int imgHeight = 0;
            if (picX.Image != null)
            {
                imgWidth = picX.Image.Width;
                imgHeight = picX.Image.Height;
            }
            else if (picY.Image != null)
            {
                imgWidth = picY.Image.Width;
                imgHeight = picY.Image.Height;
            }
            else
            {
                return;
            }
            for (int i = 0; i < imgWidth; i++)
            {
                for (int y = 0; y < imgHeight; y++)
                {
                    if (picX.Image != null)
                    {
                        vImgA_A[i, y] = (byte)Bin((int)vImgA_Grey[i, y]);
                        vImgA_R[i, y] = (byte)Bin((int)vImgA_Grey[i, y]);
                        vImgA_G[i, y] = (byte)Bin((int)vImgA_Grey[i, y]);
                        vImgA_B[i, y] = (byte)Bin((int)vImgA_Grey[i, y]);
                        vImgA_Grey[i, y] = (byte)Bin((int)vImgA_Grey[i, y]);

                        Color pixelRes = Color.FromArgb(
                            vImgA_A[i, y],
                            vImgA_R[i, y],
                            vImgA_G[i, y],
                            vImgA_B[i, y]);

                        imgA.SetPixel(i, y, pixelRes);
                    }

                    if (picY.Image != null)
                    {

                        vImgB_A[i, y] = (byte)Bin((int)vImgB_Grey[i, y]);
                        vImgB_R[i, y] = (byte)Bin((int)vImgB_Grey[i, y]);
                        vImgB_G[i, y] = (byte)Bin((int)vImgB_Grey[i, y]);
                        vImgB_B[i, y] = (byte)Bin((int)vImgB_Grey[i, y]);
                        vImgB_Grey[i, y] = (byte)Bin((int)vImgB_Grey[i, y]);

                        Color pixelRes = Color.FromArgb(
                            vImgB_A[i, y],
                            vImgB_R[i, y],
                            vImgB_G[i, y],
                            vImgB_B[i, y]);

                        imgB.SetPixel(i, y, pixelRes);
                    }
                }
                picX.Image = imgA;
                picY.Image = imgB;
            }
        }
        private void btCinza_Click(object sender, EventArgs e)
        {
            int imgWidth = 0;
            int imgHeight = 0;
            if (picX.Image != null)
            {
                imgWidth = picX.Image.Width;
                imgHeight = picX.Image.Height;
            }
            else if (picY.Image != null)
            {
                imgWidth = picY.Image.Width;
                imgHeight = picY.Image.Height;
            }
            else
            {
                return;
            }
            for (int i = 0; i < imgWidth; i++)
            {
                for (int y = 0; y < imgHeight; y++)
                {
                    if (picX.Image != null)
                    {
                        int Normalized = (vImgA_R[i, y] + vImgA_G[i, y] + vImgA_B[i, y]) / 3;
                        vImgA_R[i, y] = (byte)Normalized;
                        vImgA_G[i, y] = (byte)Normalized;
                        vImgA_B[i, y] = (byte)Normalized;

                        Color pixel = Color.FromArgb(vImgA_A[i, y],
                          vImgA_R[i, y],
                          vImgA_G[i, y],
                          vImgA_B[i, y]);

                        imgA.SetPixel(i, y, pixel);
                    }
                    if (picY.Image != null)
                    {
                        int Normalized = (vImgB_R[i, y] + vImgB_G[i, y] + vImgB_B[i, y]) / 3;
                        vImgB_R[i, y] = (byte)Normalized;
                        vImgB_G[i, y] = (byte)Normalized;
                        vImgB_B[i, y] = (byte)Normalized;

                        Color pixel = Color.FromArgb(vImgB_A[i, y],
                            vImgB_R[i, y],
                            vImgB_G[i, y],
                            vImgB_B[i, y]);

                        imgB.SetPixel(i, y, pixel);
                    }
                }
            }
            picX.Image = imgA;
            picY.Image = imgB;
        }
        private void btEqua_Click(object sender, EventArgs e)
        {
            if (imgA == null) return;
            if (!BCheckCinza(imgA))
            {
                MessageBox.Show("A imagem X deve estar em escala cinza", "Erro!", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning); return;
            }

            int width = imgA.Width;
            int height = imgA.Height;
            int[] pixelIntensityRate = new int[256];
            Bitmap imgRes = new Bitmap(imgA);

            for (int i = 0; i < width; i++)
            {
                for (int y = 0; y < height; y++)
                {
                    int pixelVal = imgA.GetPixel(i, y).R;
                    pixelIntensityRate[pixelVal]++;  ///Como a imagem vai estar em cinza, não importa qual pixel pegar
                }
            }
            double[] CFD = new double[256];
            int pixelsCount = width * width;
            CFD[0] = pixelIntensityRate[0] / (double)pixelsCount;
            for (int i = 1; i < 256; i++)
            {
                CFD[i] = CFD[i - 1] + pixelIntensityRate[i] / (double)pixelsCount;
            }

            byte[,] finalImg = new byte[width, height];

            int[] finalPixelRate = new int[256];
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    int pixel = vImgA_Grey[i, j];
                    finalImg[i, j] = (byte)Math.Round(CFD[pixel] * 255.0);
                    finalPixelRate[finalImg[i, j]]++;
                }
            }

            chist.Series.Clear();
            chist.Series.Add("Histograma A");
            chist.Series["Histograma A"].ChartType = SeriesChartType.Column;
            chist.Series["Histograma A"].Points.DataBindY(pixelIntensityRate);
            chist.ChartAreas[0].AxisY.Maximum = pixelIntensityRate.Max() + 10;

            chResult.Series.Clear();
            chResult.Series.Add("Resultado");
            chResult.Series["Resultado"].ChartType = SeriesChartType.Column;
            chResult.Series["Resultado"].Points.DataBindY(finalPixelRate);
            chResult.ChartAreas[0].AxisY.Maximum = finalPixelRate.Max() + 10;

            for (int i = 0; i < imgRes.Width; i++)
            {
                for (int j = 0; j < imgRes.Height; j++)
                {
                    byte color = finalImg[i, j];
                    Color p = Color.FromArgb(255, color, color, color);

                    imgRes.SetPixel(i, j, p);
                }
            }

            UpdateResultImage(imgRes);
        }
    }
}
