﻿
namespace ProcessamentoConversorImagem
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.lbImagemX = new System.Windows.Forms.Label();
            this.lbImagemY = new System.Windows.Forms.Label();
            this.lbArit = new System.Windows.Forms.Label();
            this.picX = new System.Windows.Forms.PictureBox();
            this.picY = new System.Windows.Forms.PictureBox();
            this.btSomar = new System.Windows.Forms.Button();
            this.btSub = new System.Windows.Forms.Button();
            this.btDivi = new System.Windows.Forms.Button();
            this.btMulti = new System.Windows.Forms.Button();
            this.btBlend = new System.Windows.Forms.Button();
            this.btMed = new System.Windows.Forms.Button();
            this.txtMulti = new System.Windows.Forms.TextBox();
            this.txtDivi = new System.Windows.Forms.TextBox();
            this.txtBlend = new System.Windows.Forms.TextBox();
            this.picResult = new System.Windows.Forms.PictureBox();
            this.lbResult = new System.Windows.Forms.Label();
            this.btUpX = new System.Windows.Forms.Button();
            this.btUpY = new System.Windows.Forms.Button();
            this.btBin = new System.Windows.Forms.Button();
            this.btCinza = new System.Windows.Forms.Button();
            this.lbLog = new System.Windows.Forms.Label();
            this.btAND = new System.Windows.Forms.Button();
            this.btOR = new System.Windows.Forms.Button();
            this.btXOR = new System.Windows.Forms.Button();
            this.btNOT = new System.Windows.Forms.Button();
            this.btMIN = new System.Windows.Forms.Button();
            this.btMedia = new System.Windows.Forms.Button();
            this.btMax = new System.Windows.Forms.Button();
            this.btSave = new System.Windows.Forms.Button();
            this.btAlea = new System.Windows.Forms.Button();
            this.lbHistX = new System.Windows.Forms.Label();
            this.btNeg = new System.Windows.Forms.Button();
            this.btEqua = new System.Windows.Forms.Button();
            this.chResult = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chist = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lbHistResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chist)).BeginInit();
            this.SuspendLayout();
            // 
            // lbImagemX
            // 
            this.lbImagemX.AutoSize = true;
            this.lbImagemX.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbImagemX.Location = new System.Drawing.Point(67, 9);
            this.lbImagemX.Name = "lbImagemX";
            this.lbImagemX.Size = new System.Drawing.Size(70, 17);
            this.lbImagemX.TabIndex = 0;
            this.lbImagemX.Text = "Imagem X";
            // 
            // lbImagemY
            // 
            this.lbImagemY.AutoSize = true;
            this.lbImagemY.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbImagemY.Location = new System.Drawing.Point(353, 9);
            this.lbImagemY.Name = "lbImagemY";
            this.lbImagemY.Size = new System.Drawing.Size(70, 17);
            this.lbImagemY.TabIndex = 1;
            this.lbImagemY.Text = "Imagem Y";
            // 
            // lbArit
            // 
            this.lbArit.AutoSize = true;
            this.lbArit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbArit.Location = new System.Drawing.Point(539, 9);
            this.lbArit.Name = "lbArit";
            this.lbArit.Size = new System.Drawing.Size(151, 17);
            this.lbArit.TabIndex = 2;
            this.lbArit.Text = "Operações Aritméticas";
            // 
            // picX
            // 
            this.picX.Location = new System.Drawing.Point(12, 32);
            this.picX.Name = "picX";
            this.picX.Size = new System.Drawing.Size(221, 221);
            this.picX.TabIndex = 3;
            this.picX.TabStop = false;
            // 
            // picY
            // 
            this.picY.Location = new System.Drawing.Point(274, 32);
            this.picY.Name = "picY";
            this.picY.Size = new System.Drawing.Size(221, 221);
            this.picY.TabIndex = 4;
            this.picY.TabStop = false;
            // 
            // btSomar
            // 
            this.btSomar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btSomar.Location = new System.Drawing.Point(574, 32);
            this.btSomar.Name = "btSomar";
            this.btSomar.Size = new System.Drawing.Size(86, 23);
            this.btSomar.TabIndex = 5;
            this.btSomar.Text = "Somar";
            this.btSomar.UseVisualStyleBackColor = true;
            this.btSomar.Click += new System.EventHandler(this.btSomar_Click);
            // 
            // btSub
            // 
            this.btSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btSub.Location = new System.Drawing.Point(574, 61);
            this.btSub.Name = "btSub";
            this.btSub.Size = new System.Drawing.Size(86, 23);
            this.btSub.TabIndex = 6;
            this.btSub.Text = "Subtrair";
            this.btSub.UseVisualStyleBackColor = true;
            this.btSub.Click += new System.EventHandler(this.btSub_Click);
            // 
            // btDivi
            // 
            this.btDivi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btDivi.Location = new System.Drawing.Point(574, 119);
            this.btDivi.Name = "btDivi";
            this.btDivi.Size = new System.Drawing.Size(86, 23);
            this.btDivi.TabIndex = 8;
            this.btDivi.Text = "Dividir";
            this.btDivi.UseVisualStyleBackColor = true;
            this.btDivi.Click += new System.EventHandler(this.btDivi_Click);
            // 
            // btMulti
            // 
            this.btMulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btMulti.Location = new System.Drawing.Point(574, 90);
            this.btMulti.Name = "btMulti";
            this.btMulti.Size = new System.Drawing.Size(86, 23);
            this.btMulti.TabIndex = 7;
            this.btMulti.Text = "Multiplicar";
            this.btMulti.UseVisualStyleBackColor = true;
            this.btMulti.Click += new System.EventHandler(this.btMulti_Click);
            // 
            // btBlend
            // 
            this.btBlend.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btBlend.Location = new System.Drawing.Point(574, 177);
            this.btBlend.Name = "btBlend";
            this.btBlend.Size = new System.Drawing.Size(86, 28);
            this.btBlend.TabIndex = 10;
            this.btBlend.Text = "Blending";
            this.btBlend.UseVisualStyleBackColor = true;
            this.btBlend.Click += new System.EventHandler(this.btBlend_Click);
            // 
            // btMed
            // 
            this.btMed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btMed.Location = new System.Drawing.Point(574, 148);
            this.btMed.Name = "btMed";
            this.btMed.Size = new System.Drawing.Size(86, 23);
            this.btMed.TabIndex = 9;
            this.btMed.Text = "Média";
            this.btMed.UseVisualStyleBackColor = true;
            this.btMed.Click += new System.EventHandler(this.btMed_Click);
            // 
            // txtMulti
            // 
            this.txtMulti.Location = new System.Drawing.Point(666, 90);
            this.txtMulti.Name = "txtMulti";
            this.txtMulti.Size = new System.Drawing.Size(61, 20);
            this.txtMulti.TabIndex = 11;
            // 
            // txtDivi
            // 
            this.txtDivi.Location = new System.Drawing.Point(666, 122);
            this.txtDivi.Name = "txtDivi";
            this.txtDivi.Size = new System.Drawing.Size(61, 20);
            this.txtDivi.TabIndex = 12;
            // 
            // txtBlend
            // 
            this.txtBlend.Location = new System.Drawing.Point(666, 182);
            this.txtBlend.Name = "txtBlend";
            this.txtBlend.Size = new System.Drawing.Size(61, 20);
            this.txtBlend.TabIndex = 13;
            // 
            // picResult
            // 
            this.picResult.Location = new System.Drawing.Point(839, 32);
            this.picResult.Name = "picResult";
            this.picResult.Size = new System.Drawing.Size(221, 221);
            this.picResult.TabIndex = 14;
            this.picResult.TabStop = false;
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbResult.Location = new System.Drawing.Point(919, 9);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(72, 17);
            this.lbResult.TabIndex = 15;
            this.lbResult.Text = "Resultado";
            // 
            // btUpX
            // 
            this.btUpX.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btUpX.Location = new System.Drawing.Point(43, 259);
            this.btUpX.Name = "btUpX";
            this.btUpX.Size = new System.Drawing.Size(146, 66);
            this.btUpX.TabIndex = 16;
            this.btUpX.Text = "Upload X";
            this.btUpX.UseVisualStyleBackColor = true;
            this.btUpX.Click += new System.EventHandler(this.btUpX_Click);
            // 
            // btUpY
            // 
            this.btUpY.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btUpY.Location = new System.Drawing.Point(329, 259);
            this.btUpY.Name = "btUpY";
            this.btUpY.Size = new System.Drawing.Size(154, 66);
            this.btUpY.TabIndex = 17;
            this.btUpY.Text = "Upload Y";
            this.btUpY.UseVisualStyleBackColor = true;
            this.btUpY.Click += new System.EventHandler(this.btUpY_Click);
            // 
            // btBin
            // 
            this.btBin.Location = new System.Drawing.Point(212, 259);
            this.btBin.Name = "btBin";
            this.btBin.Size = new System.Drawing.Size(100, 30);
            this.btBin.TabIndex = 18;
            this.btBin.Text = "RGB --> BINÁRIO";
            this.btBin.UseVisualStyleBackColor = true;
            this.btBin.Click += new System.EventHandler(this.btBin_Click);
            // 
            // btCinza
            // 
            this.btCinza.Location = new System.Drawing.Point(212, 295);
            this.btCinza.Name = "btCinza";
            this.btCinza.Size = new System.Drawing.Size(100, 30);
            this.btCinza.TabIndex = 19;
            this.btCinza.Text = "RGB --> CINZA";
            this.btCinza.UseVisualStyleBackColor = true;
            this.btCinza.Click += new System.EventHandler(this.btCinza_Click);
            // 
            // lbLog
            // 
            this.lbLog.AutoSize = true;
            this.lbLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbLog.Location = new System.Drawing.Point(554, 236);
            this.lbLog.Name = "lbLog";
            this.lbLog.Size = new System.Drawing.Size(50, 17);
            this.lbLog.TabIndex = 20;
            this.lbLog.Text = "Lógica";
            // 
            // btAND
            // 
            this.btAND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btAND.Location = new System.Drawing.Point(542, 263);
            this.btAND.Name = "btAND";
            this.btAND.Size = new System.Drawing.Size(75, 23);
            this.btAND.TabIndex = 21;
            this.btAND.Text = "AND";
            this.btAND.UseVisualStyleBackColor = true;
            this.btAND.Click += new System.EventHandler(this.btAND_Click);
            // 
            // btOR
            // 
            this.btOR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btOR.Location = new System.Drawing.Point(542, 292);
            this.btOR.Name = "btOR";
            this.btOR.Size = new System.Drawing.Size(75, 23);
            this.btOR.TabIndex = 22;
            this.btOR.Text = "OR";
            this.btOR.UseVisualStyleBackColor = true;
            this.btOR.Click += new System.EventHandler(this.btOR_Click);
            // 
            // btXOR
            // 
            this.btXOR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btXOR.Location = new System.Drawing.Point(542, 321);
            this.btXOR.Name = "btXOR";
            this.btXOR.Size = new System.Drawing.Size(75, 23);
            this.btXOR.TabIndex = 23;
            this.btXOR.Text = "XOR";
            this.btXOR.UseVisualStyleBackColor = true;
            this.btXOR.Click += new System.EventHandler(this.btXOR_Click);
            // 
            // btNOT
            // 
            this.btNOT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btNOT.Location = new System.Drawing.Point(542, 350);
            this.btNOT.Name = "btNOT";
            this.btNOT.Size = new System.Drawing.Size(75, 23);
            this.btNOT.TabIndex = 24;
            this.btNOT.Text = "NOT";
            this.btNOT.UseVisualStyleBackColor = true;
            this.btNOT.Click += new System.EventHandler(this.btNOT_Click);
            // 
            // btMIN
            // 
            this.btMIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btMIN.Location = new System.Drawing.Point(623, 263);
            this.btMIN.Name = "btMIN";
            this.btMIN.Size = new System.Drawing.Size(75, 23);
            this.btMIN.TabIndex = 25;
            this.btMIN.Text = "MINIMO";
            this.btMIN.UseVisualStyleBackColor = true;
            this.btMIN.Click += new System.EventHandler(this.btMIN_Click);
            // 
            // btMedia
            // 
            this.btMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btMedia.Location = new System.Drawing.Point(623, 302);
            this.btMedia.Name = "btMedia";
            this.btMedia.Size = new System.Drawing.Size(75, 23);
            this.btMedia.TabIndex = 26;
            this.btMedia.Text = "MÉDIA";
            this.btMedia.UseVisualStyleBackColor = true;
            this.btMedia.Click += new System.EventHandler(this.btMedia_Click);
            // 
            // btMax
            // 
            this.btMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btMax.Location = new System.Drawing.Point(623, 350);
            this.btMax.Name = "btMax";
            this.btMax.Size = new System.Drawing.Size(75, 23);
            this.btMax.TabIndex = 27;
            this.btMax.Text = "MÁXIMO";
            this.btMax.UseVisualStyleBackColor = true;
            this.btMax.Click += new System.EventHandler(this.btMax_Click);
            // 
            // btSave
            // 
            this.btSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btSave.Location = new System.Drawing.Point(874, 263);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(154, 66);
            this.btSave.TabIndex = 29;
            this.btSave.Text = "Salvar Resultado";
            this.btSave.UseVisualStyleBackColor = true;
            this.btSave.Click += new System.EventHandler(this.btSave_Click);
            // 
            // btAlea
            // 
            this.btAlea.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btAlea.Location = new System.Drawing.Point(874, 335);
            this.btAlea.Name = "btAlea";
            this.btAlea.Size = new System.Drawing.Size(154, 66);
            this.btAlea.TabIndex = 30;
            this.btAlea.Text = "Imagem Aleatória";
            this.btAlea.UseVisualStyleBackColor = true;
            this.btAlea.Click += new System.EventHandler(this.btAlea_Click);
            // 
            // lbHistX
            // 
            this.lbHistX.AutoSize = true;
            this.lbHistX.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbHistX.Location = new System.Drawing.Point(140, 412);
            this.lbHistX.Name = "lbHistX";
            this.lbHistX.Size = new System.Drawing.Size(93, 17);
            this.lbHistX.TabIndex = 32;
            this.lbHistX.Text = "Histograma X";
            // 
            // btNeg
            // 
            this.btNeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btNeg.Location = new System.Drawing.Point(522, 456);
            this.btNeg.Name = "btNeg";
            this.btNeg.Size = new System.Drawing.Size(124, 77);
            this.btNeg.TabIndex = 33;
            this.btNeg.Text = "Negativo";
            this.btNeg.UseVisualStyleBackColor = true;
            this.btNeg.Click += new System.EventHandler(this.btNeg_Click);
            // 
            // btEqua
            // 
            this.btEqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btEqua.Location = new System.Drawing.Point(522, 582);
            this.btEqua.Name = "btEqua";
            this.btEqua.Size = new System.Drawing.Size(124, 77);
            this.btEqua.TabIndex = 34;
            this.btEqua.Text = "Equalização";
            this.btEqua.UseVisualStyleBackColor = true;
            this.btEqua.Click += new System.EventHandler(this.btEqua_Click);
            // 
            // chResult
            // 
            chartArea3.Name = "ChartArea1";
            this.chResult.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chResult.Legends.Add(legend3);
            this.chResult.Location = new System.Drawing.Point(740, 465);
            this.chResult.Name = "chResult";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chResult.Series.Add(series3);
            this.chResult.Size = new System.Drawing.Size(365, 194);
            this.chResult.TabIndex = 35;
            this.chResult.Text = "chResult";
            // 
            // chist
            // 
            chartArea4.Name = "ChartArea1";
            this.chist.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chist.Legends.Add(legend4);
            this.chist.Location = new System.Drawing.Point(31, 456);
            this.chist.Name = "chist";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chist.Series.Add(series4);
            this.chist.Size = new System.Drawing.Size(365, 194);
            this.chist.TabIndex = 36;
            this.chist.Text = "char1";
            // 
            // lbHistResult
            // 
            this.lbHistResult.AutoSize = true;
            this.lbHistResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbHistResult.Location = new System.Drawing.Point(898, 433);
            this.lbHistResult.Name = "lbHistResult";
            this.lbHistResult.Size = new System.Drawing.Size(148, 17);
            this.lbHistResult.TabIndex = 37;
            this.lbHistResult.Text = "Histograma Resultado";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1117, 671);
            this.Controls.Add(this.btUpX);
            this.Controls.Add(this.lbHistResult);
            this.Controls.Add(this.chist);
            this.Controls.Add(this.chResult);
            this.Controls.Add(this.btEqua);
            this.Controls.Add(this.btNeg);
            this.Controls.Add(this.lbHistX);
            this.Controls.Add(this.btAlea);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.btMax);
            this.Controls.Add(this.btMedia);
            this.Controls.Add(this.btMIN);
            this.Controls.Add(this.btNOT);
            this.Controls.Add(this.btXOR);
            this.Controls.Add(this.btOR);
            this.Controls.Add(this.btAND);
            this.Controls.Add(this.lbLog);
            this.Controls.Add(this.btCinza);
            this.Controls.Add(this.btBin);
            this.Controls.Add(this.btUpY);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.picResult);
            this.Controls.Add(this.txtBlend);
            this.Controls.Add(this.txtDivi);
            this.Controls.Add(this.txtMulti);
            this.Controls.Add(this.btBlend);
            this.Controls.Add(this.btMed);
            this.Controls.Add(this.btDivi);
            this.Controls.Add(this.btMulti);
            this.Controls.Add(this.btSub);
            this.Controls.Add(this.btSomar);
            this.Controls.Add(this.picY);
            this.Controls.Add(this.picX);
            this.Controls.Add(this.lbArit);
            this.Controls.Add(this.lbImagemY);
            this.Controls.Add(this.lbImagemX);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbImagemX;
        private System.Windows.Forms.Label lbImagemY;
        private System.Windows.Forms.Label lbArit;
        private System.Windows.Forms.PictureBox picX;
        private System.Windows.Forms.PictureBox picY;
        private System.Windows.Forms.Button btSomar;
        private System.Windows.Forms.Button btSub;
        private System.Windows.Forms.Button btDivi;
        private System.Windows.Forms.Button btMulti;
        private System.Windows.Forms.Button btBlend;
        private System.Windows.Forms.Button btMed;
        private System.Windows.Forms.TextBox txtMulti;
        private System.Windows.Forms.TextBox txtDivi;
        private System.Windows.Forms.TextBox txtBlend;
        private System.Windows.Forms.PictureBox picResult;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Button btUpX;
        private System.Windows.Forms.Button btUpY;
        private System.Windows.Forms.Button btBin;
        private System.Windows.Forms.Button btCinza;
        private System.Windows.Forms.Label lbLog;
        private System.Windows.Forms.Button btAND;
        private System.Windows.Forms.Button btOR;
        private System.Windows.Forms.Button btXOR;
        private System.Windows.Forms.Button btNOT;
        private System.Windows.Forms.Button btMIN;
        private System.Windows.Forms.Button btMedia;
        private System.Windows.Forms.Button btMax;
        private System.Windows.Forms.Button btSave;
        private System.Windows.Forms.Button btAlea;
        private System.Windows.Forms.Label lbHistX;
        private System.Windows.Forms.Button btNeg;
        private System.Windows.Forms.Button btEqua;
        private System.Windows.Forms.DataVisualization.Charting.Chart chResult;
        private System.Windows.Forms.DataVisualization.Charting.Chart chist;
        private System.Windows.Forms.Label lbHistResult;
    }
}

